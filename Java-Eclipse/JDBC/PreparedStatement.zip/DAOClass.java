import java.sql.*;
public class DAOClass {
	public static void main(String args[]) {
		
		int command=Integer.parseInt(args[0]);
		switch(command) {
		case 1:
			try {
				int rollno=Integer.parseInt(args[1]);
				String name=args[2];
				String std=args[3];
				String dob=args[4];
				int fees=Integer.parseInt(args[5]);
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
				Statement stmt=con.createStatement();
				int rs=stmt.executeUpdate("insert into student VALUES("+rollno+","+"'"+name+"'"+","+"'"+std+"'"+","+"'"+dob+"'"+","+fees+")");
				con.close();
			}
			catch(Exception e) {
				System.out.println("Connection Could Not be Established");
				System.out.println(e);
			}
			break;
		case 2:
			try {
				int rollno=Integer.parseInt(args[1]);
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
				Statement stmt=con.createStatement();
				int rs=stmt.executeUpdate("DELETE from student WHERE rollno="+rollno);
				con.close();
			}
			catch(Exception e) {
				System.out.println("Connection Could Not be Established");
				System.out.println(e);
			}
			break;
				
		case 3:
			try {
				int rollno=Integer.parseInt(args[1]);
				int fees=Integer.parseInt(args[2]);
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
				Statement stmt=con.createStatement();
				int rs=stmt.executeUpdate("update student set fees="+fees+" WHERE rollno="+rollno);
				con.close();
			}
			catch(Exception e) {
				System.out.println("Connection Could Not be Established");
				System.out.println(e);
			}
			break;
			
		case 4:
			try {
				if(args.length==2)
				{
					int rollno=Integer.parseInt(args[1]);
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery("select * from student where rollno="+rollno);
					while(rs.next())
						System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5));
					con.close();
				}
				else
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery("select * from student");
					while(rs.next())
						System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5));
					con.close();
				}
			}
			catch(Exception e) {
				System.out.println("Connection Could Not be Established");
				System.out.println(e);
			}
			break;
				
			}
		
		}
}
