import java.sql.*;
public class EstablishConnection2 {
	public static void main(String args[]) {
		try {
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
			Statement stmt=con.createStatement();
			System.out.println("Connection established successfully");
			con.close();
		}
		catch(Exception e) {
			System.out.println("Connection Could Not be Established");
			System.out.println(e);
		}
	}

}
