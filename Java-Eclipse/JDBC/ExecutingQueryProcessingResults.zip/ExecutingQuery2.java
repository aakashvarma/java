import java.sql.*;
public class ExecutingQuery2 {
	public static void main(String args[]) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select first_name, job_id, salary, commission_pct from employees where (salary>1000 and salary<2000)");
			while(rs.next())
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4));
			con.close();
		}
		catch(Exception e) {
			System.out.println("Connection Could Not be Established");
			System.out.println(e);
		}
	}

}