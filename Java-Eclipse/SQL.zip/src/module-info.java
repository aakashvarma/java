/**
 * 
 */
/**
 * @author SAURAV ROY
 *
 */
module sql {
	requires java.sql;
}