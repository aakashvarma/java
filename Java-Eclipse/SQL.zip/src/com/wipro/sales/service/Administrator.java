package com.wipro.sales.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.List;

import com.wipro.sales.bean.SalesReport;
import com.wipro.sales.bean.Stock;
import com.wipro.sales.bean.sales;
import com.wipro.sales.dao.SalesDoa;
import com.wipro.sales.dao.StockDao;
import com.wipro.sales.main.SalesApplication;
import com.wipro.sales.util.DBUtil;

public class Administrator {
	private static java.sql.Date convertUtilToSql(java.util.Date uDate){
		java.sql.Date sDate=new java.sql.Date(uDate.getTime());
		return sDate;
	}
	
	public String  insertStock(Stock sale) {
		Connection con=DBUtil.getDBConnection();
		
		StockDao s=new StockDao();
		String id=sale.getProduct_ID();
		String name=sale.getProduct_Name();
		int quantonhand=sale.getQuantity_On_Hand();
		int price=sale.getProduct_Unit_Price();
		int reorder=sale.getReorder_Level();
		
		
		if(name.length()>=2 && sale!=null) {
			
			id= s.generateProdutID(name)+id;
			try {
				 PreparedStatement pred=con.prepareStatement("INSERT INTO `crunchify`.`tbl_stock`\r\n" + 
			        		"(`Product_ID`,\r\n" + 
			        		" `Product_Name`,\r\n" + 
			        		" `Quantity_On_Hand`,\r\n" + 
			        		" `Product_Unit_Price`,\r\n" + 
			        		" `Reorder_Level`)\r\n" + 
			        		"VALUES ('"+id+"','"+name+"',"+quantonhand+","+price+","+reorder+");");
				             pred.execute();
				             con.close();
				}
				catch(Exception e) {
					System.out.print(e);
				}
			return id;
		}
		else {
		
		return "Data not valid for insertion";
	}
	}
	
	
	public String deleteStock(String productID) {
		StockDao s=new StockDao();
		try {
		s.deleteStock(productID);
		return "delete";
		}
		catch(Exception e) {
			return "record cannot be deleted";
		}
		
	}
	
	//insert sales
	public String insertSales(sales saleobj) {
		SalesDoa sl=new SalesDoa();
		if(saleobj!=null) {
			int qtyhnd = 0; //from tbl_stock
			String id=saleobj.getProductID();
			System.out.println("idcheck: "+id);
			Connection c=DBUtil.getDBConnection();
			try {
				Statement statement=c.createStatement();
				ResultSet rs=statement.executeQuery("select * from crunchify.tbl_stock where Product_ID=\""+id+"\"");
				while(rs.next()) {
					qtyhnd=rs.getInt("Quantity_On_Hand");
					
				}
			}
			catch(Exception e) {
				System.out.print(e);
				return "Invalid ProductID";
			}
			
			
			int qtysold=saleobj.getQuantitySold();
			
			
			System.out.println("qtysold :"+qtysold);
			
			if(qtyhnd<qtysold) {
				return "Oops!! Not Enough stock";
			}
			String saleid=saleobj.getSalesID();
				
			java.util.Date d= new java.util.Date();
			d=saleobj.getSalesDate();
			java.sql.Date sDate=convertUtilToSql(d);
			
		
		
			
			saleid=saleid+sl.generateSalesID(d);
			System.out.println("sales_ID check:: "+saleid);
			int saleprice=saleobj.getSalesPerUnit();
			
			sales s=new sales();
			s.setSalesID(saleid);
			s.setProductID(id);
			s.setQuantitySold(qtysold);
			s.setSalesPerUnit(saleprice);
			s.setSalesDate(sDate);
			
			sl.insertSales(s);
			System.out.println("INSERTED..............");
			StockDao std=new StockDao();
			std.updateStock(id, qtysold);
			System.out.println("UPDATED............");
			return "Transaction Successfull";
			
		}
		else {
			return "Failed";
		}
		
	}
	

	public void reporting() {
		
		SalesDoa sd=new SalesDoa();
		 sd.getSalesReport();
		
	}
}
