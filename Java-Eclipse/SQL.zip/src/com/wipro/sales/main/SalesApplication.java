package com.wipro.sales.main;

import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.wipro.sales.bean.SalesReport;
import com.wipro.sales.bean.Stock;
import com.wipro.sales.bean.sales;
import com.wipro.sales.dao.SalesDoa;
import com.wipro.sales.service.Administrator;
import com.wipro.sales.util.DBUtil;

public class SalesApplication<S> {
	
	private static java.sql.Date convertUtilToSql(java.util.Date uDate){
		java.sql.Date sDate=new java.sql.Date(uDate.getTime());
		return sDate;
	}
	public int sidret() {
		int sid=0;
		Connection c=DBUtil.getDBConnection();
		try {
		 Statement statement2 = c.createStatement();
	     ResultSet rs2 = statement2.executeQuery("select * from crunchify.sale_seq");
	     while(rs2.next()) {
			sid=rs2.getInt("sale_id");
	     }
	}
		catch(Exception e) {
			System.out.print(e);
		}
		
		return sid;
	}
	
	
	public static void main(String[] args) throws InterruptedException, SQLException, ParseException {
		
		int pid=0;
		//int sid=0;
		Connection c=DBUtil.getDBConnection();
		Statement statement1 = c.createStatement();
      ResultSet rs1 = statement1.executeQuery("select * from crunchify.prod_seq");
     while(rs1.next()) {
		 pid=rs1.getInt("prod_id");
     }
    
     SalesApplication sa=new SalesApplication();
     int sid=sa.sidret();
//     System.out.print("sid=== "+sid);
     
		System.out.println("Welcome to Business Manager App....");
		Thread.sleep(100);
		System.out.println("Main Menu:");
		System.out.println("1.Insert Stock");
		System.out.println("2.Delete Stock");
		System.out.println("3.insert sales");
		System.out.println("4.View Report");
		int a;
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		
		Administrator admin=new Administrator();
		if(a==1) { // update the sid and then call them in function 
			
			
			Stock st=new Stock();
			System.out.println("Product Name: ");
			String name=sc.next();
			st.setProduct_Name(name);
			String product_ID=Integer.toString(pid);
			int p=pid+1;			
			
			try {
				PreparedStatement pd=c.prepareStatement("update crunchify.prod_seq set prod_id="+p+" where prod_id="+pid+"");
				pd.execute();
			}
			catch(Exception e){
				System.out.print(e);
			}
			
			
			st.setProduct_ID(product_ID);
		
			System.out.println("Quantity on Hand :");
			int qty=sc.nextInt();
			st.setQuantity_On_Hand(qty);
			
			System.out.println("Product Unit Price:");
			int prodprice=sc.nextInt();
			st.setProduct_Unit_Price(prodprice);
		
			System.out.println("Reorder level");
			int re=sc.nextInt();
			st.setReorder_Level(re);
			admin.insertStock(st);
			System.out.println("Stocks Updated..............");
			}
		if(a==2) {
			System.out.print("Enter Product_Id to be deleted: ");
			String productID=sc.next();
			admin.deleteStock(productID);
			System.out.print(productID+"deleted: ");
		}
		if(a==3) {	
			sales ob=new sales();
			System.out.println("Product id :");
			String product_ID=sc.next();
//			String product_ID=Integer.toString(pid);
			ob.setProductID(product_ID);
			
			//System.out.println("Sales ID: "+sid);
			String sales_ID=Integer.toString(sid);
			ob.setSalesID(sales_ID);
			int s=sid+1;
			try {
				PreparedStatement pd=c.prepareStatement("update crunchify.sale_seq set sale_id="+s+" where sale_id="+sid+"");
				pd.execute();
			}
			catch(Exception e){
				System.out.print(e);
			}
			
		
			
			
			System.out.print("Sales Date : ");
			String d=sc.next();
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
			Date testdate=sdf.parse(d);
		java.sql.Date sDate=convertUtilToSql(testdate);
			
		ob.setSalesDate(sDate);
			System.out.println("Quantity Sold: ");
			int qty=sc.nextInt();
			ob.setQuantitySold(qty);
			
			System.out.println("Sales_Price_per_Unit: ");
			int saleprice=sc.nextInt();
			ob.setSalesPerUnit(saleprice);
			
			admin.insertSales(ob);
			
		}
	
	
if(a==4) {
	Administrator adm=new Administrator();
	
	adm.reporting();
	}
	
	
}
}
