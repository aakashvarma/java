package com.wipro.sales.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.wipro.sales.bean.SalesReport;
import com.wipro.sales.bean.Stock;
import com.wipro.sales.bean.sales;
import com.wipro.sales.util.DBUtil;

public class StockDao {
	public void insertStock(Stock sale) {
		Connection con=DBUtil.getDBConnection();
		String id=sale.getProduct_ID();
		String name=sale.getProduct_Name();
		int quantonhand=sale.getQuantity_On_Hand();
		int price=sale.getProduct_Unit_Price();
		int reorder=sale.getReorder_Level();
		try {
		 PreparedStatement pred=con.prepareStatement("INSERT INTO `crunchify`.`tbl_stock`\r\n" + 
	        		"(`Product_ID`,\r\n" + 
	        		" `Product_Name`,\r\n" + 
	        		" `Quantity_On_Hand`,\r\n" + 
	        		" `Product_Unit_Price`,\r\n" + 
	        		" `Reorder_Level`)\r\n" + 
	        		"VALUES ('"+id+"','"+name+"',"+quantonhand+","+price+","+reorder+");");
		             pred.execute();
		            con.close();
		}
		catch(Exception e) {
			System.out.print(e);
		}
	}
	
	public String generateProdutID(String productname) {
		String res="";
		
       res=res+productname.charAt(0)+productname.charAt(1);
       //after getting the generate product ID as return add the seq_product_id declared in main for new product
	return res;
	}
	
	
	//updating stock
	public void updateStock(String Product_ID,int soldQty) {
Connection con=DBUtil.getDBConnection();
try {
	PreparedStatement pred=con.prepareStatement("UPDATE crunchify.tbl_stock SET Quantity_On_Hand =Quantity_On_Hand -"+soldQty+" where Product_ID=\""+Product_ID+"\"");
	pred.execute();
	con.close();
}
catch(Exception e) {
	System.out.print(e);
}

	}
	
	//return specific object function
	
	public List<Stock> getStock(String Product_ID) {
		List<Stock> stock = new ArrayList<Stock>();
		Connection con=DBUtil.getDBConnection();
		try {
			Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM crunchify.tbl_stock where Product_ID=\""+Product_ID+"\"");
			
            while(rs.next()) {
            	String id=rs.getString("Product_ID");
	             String name=rs.getString("Product_Name");
	             int quan=rs.getInt("Quantity_On_Hand");
	             int price=rs.getInt("Product_Unit_Price");
	             int re=rs.getInt("Reorder_Level");
	             final Stock st =new Stock(id,name,quan,price,re);
	             stock.add(st);
            }
			con.close();
			
		}
		catch(Exception e) {
			System.out.print(e);
		}
		
		return stock;
		
	}
	// deleting the stock with the given product id .
	public void deleteStock(String productID) {
		Connection con=DBUtil.getDBConnection();
		
		try {
			PreparedStatement pred=con.prepareStatement("delete from crunchify.tbl_stock where Product_ID=\""+productID+"\";");
			pred.execute();
			
			con.close();
			
		}
		catch(Exception e){
			System.out.print(e);
		}
		
	}
	
	

}
