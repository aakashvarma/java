package com.wipro.sales.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import com.wipro.sales.bean.SalesReport;
import com.wipro.sales.bean.sales;
import com.wipro.sales.util.DBUtil;

public class SalesDoa {
		public void insertSales(sales sale) {
			 try {
			Connection con=DBUtil.getDBConnection();
			 String saleid= sale.getSalesID();
			 Date date= sale.getSalesDate();
			 String proid= sale.getProductID();
			 int quant= sale.getQuantitySold();
			int  saleunit= sale.getSalesPerUnit();
			PreparedStatement pred=con.prepareStatement("insert into crunchify.tbl_sales values(\""+saleid+"\",'"+date+"',\""+proid+"\","+quant+","+saleunit+")");
			pred.execute();
		    con.close();
		        }
			 catch(Exception e){
		            System.out.println(e);
		        }
			
}
		
		public String generateSalesID(Date date) {
			String res="";
			
		        // Display a date in day, month, year format
		        DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		        String today = formatter.format(date);
		       // System.out.println("Today : " + today);
		        String last2Digit=  today.substring(today.length()-2);
		        res=res+last2Digit;
		      //after getting the generte sales ID as return add the seq_sales_id declared in main for new product
			return res;
		}
		
		public void getSalesReport()   {
		
			System.out.println("Wait...Report Generating");
			try {
			Thread.sleep(1000);
			}
			catch(Exception e) {
				
			}
			try {
			Connection con=DBUtil.getDBConnection();
			 Statement statement = con.createStatement();
	            ResultSet rs = statement.executeQuery("select * from crunchify.sales_report");
//	           final SalesReport sr=new SalesReport();
	            
	           System.out.println("Sales_ID "+"Sales_Date"+" Product-Id "+" Product Name"+" Quantity_sold"+ " Sale_Price"+ "Profit_Amount");
	            while(rs.next()) {
	            	String salesID=rs.getString("Sales_ID");
	            	 Date salesDat=rs.getDate("Sales_Date");
	            	String productID=rs.getString("Product_ID");
	            	String productName=rs.getString("Product_Name");
	            	 int quantitySold=rs.getInt("Quantity_Sold");
	            	int productUnitPrice=rs.getInt("Product_Unit_Price");
	            	int salesPriceperUnit=rs.getInt("Sales_Price_Per_Unit");
	            	int profitAmount=rs.getInt("Profit_Amount");
	            	
	            System.out.print(salesID+"   "+salesDat+"   "+productID+"   "+productName+"   "+quantitySold+"   "+productUnitPrice+"   "+salesPriceperUnit+"   "+profitAmount);
            	System.out.println("");
	            }
	            con.close();
			}
			catch(Exception e) {
				System.out.print(e);
			}
			//return report;
			
		}
			
}
