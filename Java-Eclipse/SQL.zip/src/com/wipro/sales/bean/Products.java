package com.wipro.sales.bean;

public class Products {
		private String ProductID;
		private String productName;
		private int quantityOnHand;
		private int productUnitPrice;
		private int reorderLevel;

	 


	    public Products() {
	    }

	    public Products(String productID, String productName, int quantityOnHand, int productUnitPrice, int reorderLevel) {
	        ProductID = productID;
	        this.productName = productName;
	        this.quantityOnHand = quantityOnHand;
	        this.productUnitPrice = productUnitPrice;
	        this.reorderLevel = reorderLevel;
	    }
	    
	    public String getProductID() {
	        return ProductID;
	    }

	    public void setProductID(String productID) {
	        ProductID = productID;
	    }

	    public String getProductName() {
	        return productName;
	    }

	    public void setProductName(String productName) {
	        this.productName = productName;
	    }

	    public int getQuantityOnHand() {
	        return quantityOnHand;
	    }

	    public void setQuantityOnHand(int quantityOnHand) {
	        this.quantityOnHand = quantityOnHand;
	    }

	    public int getProductUnitPrice() {
	        return productUnitPrice;
	    }

	    public void setProductUnitPrice(int productUnitPrice) {
	        this.productUnitPrice = productUnitPrice;
	    }

	    public int getReorderLevel() {
	        return reorderLevel;
	    }

	    public void setReorderLevel(int reorderLevel) {
	        this.reorderLevel = reorderLevel;
	    }
	    
}
