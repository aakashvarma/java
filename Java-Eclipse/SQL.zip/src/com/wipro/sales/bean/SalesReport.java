package com.wipro.sales.bean;
import java.util.*;
public class SalesReport {
	private String salesID;
	private Date salesDate;
	private String productID;
	private String productName;
	private int quantitySold;
	private int productUnitPrice;
	private int salesPriceperUnit;
	private int profitAmount;
	 public SalesReport() {
	    }

	    public SalesReport(String salesID, Date salesDate, String productID, String productName, int quantitySold, int productUnitPrice, int salesPriceperUnit, int profitAmount) {
	        this.salesID = salesID;
	        this.salesDate = salesDate;
	        this.productID = productID;
	        this.productName = productName;
	        this.quantitySold = quantitySold;
	        this.productUnitPrice = productUnitPrice;
	        this.salesPriceperUnit = salesPriceperUnit;
	        this.profitAmount = profitAmount;
	    }

	    public String getSalesID() {
	        return salesID;
	    }

	    public void setSalesID(String salesID) {
	        this.salesID = salesID;
	    }

	    public Date getSalesDate() {
	        return salesDate;
	    }

	    public void setSalesDate(Date salesDate) {
	        this.salesDate = salesDate;
	    }

	    public String getProductID() {
	        return productID;
	    }

	    public void setProductID(String productID) {
	        this.productID = productID;
	    }

	    public String getProductName() {
	        return productName;
	    }

	    public void setProductName(String productName) {
	        this.productName = productName;
	    }

	    public int getQuantitySold() {
	        return quantitySold;
	    }

	    public void setQuantitySold(int quantitySold) {
	        this.quantitySold = quantitySold;
	    }

	    public int getProductUnitPrice() {
	        return productUnitPrice;
	    }

	    public void setProductUnitPrice(int productUnitPrice) {
	        this.productUnitPrice = productUnitPrice;
	    }

	    public int getSalesPriceperUnit() {
	        return salesPriceperUnit;
	    }

	    public void setSalesPriceperUnit(int salesPriceperUnit) {
	        this.salesPriceperUnit = salesPriceperUnit;
	    }

	    public int getProfitAmount() {
	        return profitAmount;
	    }

	    public void setProfitAmount(int profitAmount) {
	        this.profitAmount = profitAmount;
	    }
	
}
