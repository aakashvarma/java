package com.wipro.sales.bean;

public class Stock {
	private String Product_ID;
	private String  Product_Name;
	
	private int Quantity_On_Hand ;
	private int Product_Unit_Price;
	private int Reorder_Level;
	 public Stock() {
	    }

	    public Stock(String product_ID, String product_Name, int quantity_On_Hand, int product_Unit_Price, int reorder_Level) {
	        Product_ID = product_ID;
	        Product_Name = product_Name;
	        Quantity_On_Hand = quantity_On_Hand;
	        Product_Unit_Price = product_Unit_Price;
	        Reorder_Level = reorder_Level;
	    }

	    public String getProduct_ID() {
	        return Product_ID;
	    }

	    public void setProduct_ID(String product_ID) {
	        Product_ID = product_ID;
	    }

	    public String getProduct_Name() {
	        return Product_Name;
	    }

	    public void setProduct_Name(String product_Name) {
	        Product_Name = product_Name;
	    }

	    public int getQuantity_On_Hand() {
	        return Quantity_On_Hand;
	    }

	    public void setQuantity_On_Hand(int quantity_On_Hand) {
	        Quantity_On_Hand = quantity_On_Hand;
	    }

	    public int getProduct_Unit_Price() {
	        return Product_Unit_Price;
	    }

	    public void setProduct_Unit_Price(int product_Unit_Price) {
	        Product_Unit_Price = product_Unit_Price;
	    }

	    public int getReorder_Level() {
	        return Reorder_Level;
	    }

	    public void setReorder_Level(int reorder_Level) {
	        Reorder_Level = reorder_Level;
	    }
}
