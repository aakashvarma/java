package com.wipro.sales.bean;
import java.util.Date;
public class sales {
	private String salesID;
	private Date salesDate;
	private String productID;
	private int quantitySold;
	private int salesPerUnit;
	
	public sales() {
    }

    public sales(String salesID, Date salesDate, String productID, int quantitySold, int salesPerUnit) {
        this.salesID = salesID;
        this.salesDate = salesDate;
        this.productID = productID;
        this.quantitySold = quantitySold;
        this.salesPerUnit = salesPerUnit;
    }

    public String getSalesID() {
        return salesID;
    }

    public void setSalesID(String salesID) {
        this.salesID = salesID;
    }

    public Date getSalesDate() {
        return  salesDate;
    }

    public void setSalesDate(Date salesDate) {
        this.salesDate = salesDate;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public int getQuantitySold() {
        return quantitySold;
    }

    public void setQuantitySold(int quantitySold) {
        this.quantitySold = quantitySold;
    }

    public int getSalesPerUnit() {
        return salesPerUnit;
    }

    public void setSalesPerUnit(int salesPerUnit) {
        this.salesPerUnit = salesPerUnit;
    }
}
