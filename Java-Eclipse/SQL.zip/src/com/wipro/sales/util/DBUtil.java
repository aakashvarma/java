package com.wipro.sales.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBUtil {
	public static Connection getDBConnection(){
	 
	

		// TODO Auto-generated method stub
		Connection con = null;
		//boolean status=true;
		try{  
			
			Class.forName("com.mysql.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306?autoReconnect=true&useSSL=false","root","Sroyvit123#");  
			
		}
		catch(Exception e)
		{ 
				System.out.println("Not Connected");
				System.out.println(e);
				}
		
		return con;


}
	
	
//	public static  void main(String[] args) throws InterruptedException{
//		 
//		 for(int i=0;i<20;i++) {
//			 System.out.print(".");
//			 Thread.sleep(100);
//		 }
//		// System.out.println("");
//		 
//	        try {
//	   
//	            Connection c = getDBConnection();
////        PreparedStatement pred=c.prepareStatement("INSERT INTO `crunchify`.`tbl_stock`\r\n" + 
////        		"(`Product_ID`,\r\n" + 
////        		" `Product_Name`,\r\n" + 
////        		" `Quantity_On_Hand`,\r\n" + 
////        		" `Product_Unit_Price`,\r\n" + 
////        		" `Reorder_Level`)\r\n" + 
////        		"VALUES ('GA1005','Galaxy',36,20500,5);");delete from crunchify.tbl_stock where Product_ID=\""+productID+"\"
//	            
////	            pred.execute();
//	            Statement statement = c.createStatement();
//	            ResultSet rs = statement.executeQuery("select * from crunchify.tbl_stock");
//	            
//	            boolean status=c.isClosed();
//	            if(status==false) {
//	            	System.out.print("DataBase Connected Successfully :- ");
//	            	Thread.sleep(100);
//	            }
//	            System.out.println("");
//	            while (rs.next()){
//	             String id=rs.getString("Product_ID");
//	             String name=rs.getString("Product_Name");
//	             int quan=rs.getInt("Quantity_On_Hand");
//	             int price=rs.getInt("Product_Unit_Price");
//	             int re=rs.getInt("Reorder_Level");
//	             System.out.println(id+" "+name+" "+quan+ " "+price+ " "+ re);
//
//	            }
//	            c.close();
//	        }
//	        catch(Exception e){
//	            System.out.println(e);
//	        }
//	    }
	
}
