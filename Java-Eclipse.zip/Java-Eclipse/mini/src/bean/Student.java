package bean;

public class Student {
	public String name;
	public int marks[];
	
	public Student() {
		
	}
	public Student(String name, int[] marks)
	{
		this.name = name;
		this.marks = marks;
	}
}
