package testing;

public class Demo1 {
	public String stringConcat(String s1, String s2) {
		return s1 + s2;
	}
}
