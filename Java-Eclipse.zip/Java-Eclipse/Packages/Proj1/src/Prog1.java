import test.*;

public class Prog1 {
	public static void main(String[] args) {
		foundation obj = new foundation();
		System.out.println(obj.var1);
		System.out.println(obj.var2);
		System.out.println(obj.var3);
		System.out.println(obj.var4);
	}
}
