package test;

public class foundation {
	private int var1 = 0;
	int var2 = 1;
	protected int var3 = 2;
	public int var4 = 3;
}
