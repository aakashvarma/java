class TestEmployee {
    public static void main(String[] args) {
        Employee emp = new Employee("Rohit", 27000.00, 2018, "4156203");
        emp.getName();
        emp.getSalary();
        emp.getYearOfWork();
        emp.getInsureNo();
    }
}